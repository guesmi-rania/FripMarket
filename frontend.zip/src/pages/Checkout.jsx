function Checkout() {
    return (
      <div style={{ padding: '2rem' }}>
        <h2>Paiement réussi !</h2>
        <p>Merci pour votre achat sur FripeChic.</p>
      </div>
    );
  }
  
  export default Checkout;
  