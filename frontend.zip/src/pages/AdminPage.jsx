import React from 'react';

const AdminPage = () => (
  <div className="p-6 text-center">
    <h2 className="text-3xl font-bold">Admin</h2>
    <p>Interface d’administration des produits.</p>
  </div>
);

export default AdminPage;
