import React from 'react';
import HeroSlider from '../components/HeroSlider';
import Categories from '../components/Categories';
import ProductShowcase from '../components/ProductShowcase';

const HomePage = () => {
  return (
    <div>
      <HeroSlider />
      <Categories />
      <ProductShowcase />
    </div>
  );
};

export default HomePage;
