import React, { useState } from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="bg-green-600 text-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center p-4">
        {/* Logo */}
        <Link to="/" className="text-2xl font-bold tracking-wider">
          🛍️ FripMarket
        </Link>

        {/* Menu desktop */}
        <nav className="hidden md:flex space-x-6 font-semibold">
          <Link to="/" className="hover:text-green-200 transition">Accueil</Link>
          <Link to="/sell" className="hover:text-green-200 transition">Vendre</Link>
        </nav>

        {/* Menu mobile toggle */}
        <button
          className="md:hidden focus:outline-none"
          onClick={() => setOpen(!open)}
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d={open ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
            />
          </svg>
        </button>
      </div>

      {/* Menu mobile */}
      {open && (
        <nav className="md:hidden bg-green-500 text-white flex flex-col space-y-2 p-4">
          <Link to="/" className="hover:text-green-200 transition" onClick={() => setOpen(false)}>Accueil</Link>
          <Link to="/sell" className="hover:text-green-200 transition" onClick={() => setOpen(false)}>Vendre</Link>
        </nav>
      )}
    </header>
  );
}
