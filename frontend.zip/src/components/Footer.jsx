import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-black text-white text-center p-4 mt-8">
      © 2025 FripMarket. Tous droits réservés.
    </footer>
  );
};

export default Footer;
