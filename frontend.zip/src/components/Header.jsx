import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => (
  <header className="bg-white shadow-md sticky top-0 z-50">
    <div className="max-w-7xl mx-auto flex justify-between items-center p-4">
      <Link to="/" className="text-2xl font-bold">FripMarket</Link>
      <nav className="space-x-6 hidden md:flex">
        <Link to="/" className="hover:text-gray-700">Home</Link>
        <Link to="/products" className="hover:text-gray-700">Produits</Link>
        <Link to="/cart" className="hover:text-gray-700">Panier</Link>
        <Link to="/admin" className="hover:text-gray-700">Admin</Link>
      </nav>
    </div>
  </header>
);

export default Header;
