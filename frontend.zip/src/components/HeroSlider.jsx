import React, { useState, useEffect } from 'react';

const slides = [
  { id: 1, image: '/images/slide1.jpg', title: 'Nouvelle Collection Automne', subtitle: 'Vêtements et Accessoires de Qualité' },
  { id: 2, image: '/images/slide2.jpg', title: 'Découvrez nos Promotions', subtitle: 'Sélection exclusive de vêtements' },
];

const HeroSlider = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setCurrent((prev) => (prev + 1) % slides.length), 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative h-[80vh] w-full overflow-hidden">
      {slides.map((slide, index) => (
        <div key={slide.id} className={`absolute inset-0 transition-opacity duration-1000 ${index === current ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}>
          <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black bg-opacity-30 flex flex-col justify-center items-center text-center px-4">
            <h2 className="text-white text-4xl md:text-6xl font-light mb-4">{slide.title}</h2>
            <p className="text-white text-lg md:text-2xl">{slide.subtitle}</p>
          </div>
        </div>
      ))}
      <button onClick={() => setCurrent((current - 1 + slides.length) % slides.length)} className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white text-black rounded-full w-10 h-10 hover:bg-gray-200">‹</button>
      <button onClick={() => setCurrent((current + 1) % slides.length)} className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white text-black rounded-full w-10 h-10 hover:bg-gray-200">›</button>
    </section>
  );
};

export default HeroSlider;
